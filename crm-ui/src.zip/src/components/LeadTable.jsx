import { useState } from "react";
import { Search, ArrowRight, Flag } from "lucide-react";
import { Card, CardHeading, Avatar, EmptyState } from "./ui";

const statusStyles = {
    New: "bg-teal-50 text-teal-900 ring-teal-200",
    "In Progress": "bg-amber-50 text-amber-900 ring-amber-200",
    "Follow-up": "bg-sky-50 text-sky-900 ring-sky-200",
    Won: "bg-emerald-50 text-emerald-900 ring-emerald-200",
    Lost: "bg-rose-50 text-rose-900 ring-rose-200",
};

const priorityStyles = {
    High: "text-rose-700",
    Medium: "text-amber-800",
    Low: "text-emerald-800",
};

export default function LeadTable({ leads, compact = false, onViewAll }) {
    const [search, setSearch] = useState("");

    const filtered = leads.filter((lead) =>
        [
            lead.customer,
            lead.contact,
            lead.division,
            lead.description,
            lead.status,
            lead.leadSource,
            lead.referredBy?.name,
            lead.referredBy?.company,
            lead.referredBy?.phone,
            lead.referredBy?.email,
        ]
            .filter(Boolean)
            .join(" ")
            .toLowerCase()
            .includes(search.trim().toLowerCase())
    );

    const displayed = compact ? filtered.slice(0, 5) : filtered;

    return (
        <Card>
            <CardHeading
                title={compact ? "Recent leads" : "All leads"}
                description="Track every customer conversation."
            >
                <label className="flex w-full items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-600 transition-colors focus-within:border-teal-600 focus-within:ring-2 focus-within:ring-teal-100 sm:w-auto">
                    <Search size={16} />
                    <input
                        aria-label="Search leads"
                        placeholder="Search leads..."
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        className="w-full bg-transparent text-xs text-slate-900 outline-none placeholder:text-slate-500 sm:w-40"
                    />
                </label>
            </CardHeading>

            <div className="grid gap-3 px-3 pb-3 sm:grid-cols-2 lg:hidden">
                {displayed.map((lead) => <article key={lead.id} className="min-w-0 rounded-xl border border-slate-200 bg-white p-3 shadow-sm shadow-slate-900/5 transition-shadow duration-200 hover:shadow-md">
                    <div className="flex items-start gap-2.5"><Avatar name={lead.customer} /><div className="min-w-0"><strong className="block break-words text-xs font-semibold text-slate-950">{lead.customer}</strong><p className="mt-1 text-[11px] text-slate-600">{lead.contact || "Contact not added"}</p></div></div>
                    <p className="my-3 break-words text-xs leading-5 text-slate-700">{lead.description}</p>
                    <div className="flex flex-wrap items-center gap-2"><span className={`rounded-md px-2 py-1 text-[10px] font-semibold ring-1 ring-inset ${statusStyles[lead.status] || "bg-slate-100 text-slate-900 ring-slate-200"}`}>{lead.status}</span><span className={`inline-flex items-center gap-1 text-[11px] font-semibold ${priorityStyles[lead.priority] || "text-slate-700"}`}><Flag size={11} />{lead.priority}</span></div>
                    <dl className="mt-3 space-y-1.5 border-t border-slate-100 pt-3 text-[11px]"><div className="flex justify-between gap-3"><dt className="text-slate-600">Division</dt><dd className="text-right font-medium text-slate-900">{lead.division}</dd></div><div className="flex justify-between gap-3"><dt className="shrink-0 text-slate-600">Referred by</dt><dd className="min-w-0 break-words text-right font-medium text-teal-900">{lead.referredBy?.name || lead.leadSource || "Not specified"}</dd></div></dl>
                </article>)}
            </div>
            <div className="hidden overflow-x-auto lg:block">
                <table className="w-full border-collapse whitespace-nowrap text-left">
                    <thead className="border-y border-slate-200 bg-slate-50 text-[10px] font-bold uppercase tracking-wider text-slate-700">
                        <tr>
                            {["Customer", "Division", "Referred By", "Requirement", "Status", "Priority"].map(
                                (label) => (
                                    <th key={label} className="px-5 py-3">
                                        {label}
                                    </th>
                                )
                            )}
                        </tr>
                    </thead>

                    <tbody className="divide-y divide-slate-100">
                        {displayed.map((lead) => (
                            <tr
                                key={lead.id}
                                className="text-xs text-slate-700 transition-colors hover:bg-teal-50/50"
                            >
                                <td className="px-5 py-4">
                                    <div className="flex items-center gap-3">
                                        <Avatar name={lead.customer} />
                                        <div>
                                            <strong className="block font-semibold text-slate-950">
                                                {lead.customer}
                                            </strong>
                                            <small className="mt-1 block text-[11px] text-slate-600">
                                                {lead.contact || "Contact not added"}
                                            </small>
                                        </div>
                                    </div>
                                </td>

                                <td className="px-5 py-4 font-medium text-slate-800">
                                    {lead.division}
                                </td>

                                <td className="px-5 py-4">
                                    {lead.referredBy ? <div>
                                        <strong className="block text-xs font-semibold text-slate-950">{lead.referredBy.name}</strong>
                                        {lead.referredBy.company && <small className="mt-1 block text-[11px] text-slate-700">{lead.referredBy.company}</small>}
                                        <span className="mt-1 inline-block rounded-md bg-teal-50 px-2 py-1 text-[10px] font-semibold text-teal-900">{lead.leadSource}</span>
                                    </div> : <span className="text-xs text-slate-600">{lead.leadSource || "Not specified"}</span>}
                                </td>

                                <td className="px-5 py-4">{lead.description}</td>

                                <td className="px-5 py-4">
                                    <span
                                        className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-[10px] font-semibold ring-1 ring-inset ${statusStyles[lead.status] ||
                                            "bg-slate-100 text-slate-900 ring-slate-200"
                                            }`}
                                    >
                                        <i className="size-1 rounded-full bg-current" />
                                        {lead.status}
                                    </span>
                                </td>

                                <td className="px-5 py-4">
                                    <span
                                        className={`inline-flex items-center gap-1.5 text-[11px] font-semibold ${priorityStyles[lead.priority] || "text-slate-700"
                                            }`}
                                    >
                                        <Flag size={12} />
                                        {lead.priority}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

            </div>
                {displayed.length === 0 && (
                    <EmptyState
                        icon={Search}
                        title="No matching leads"
                        description="Try another customer name or requirement."
                    />
                )}
            <footer className="flex items-center justify-between gap-4 border-t border-slate-200 px-5 py-4 text-[11px] text-slate-600">
                <span>
                    Showing {displayed.length} of {filtered.length} leads
                </span>

                {compact && (
                    <button
                        type="button"
                        onClick={onViewAll}
                        className="inline-flex items-center gap-1.5 font-semibold text-teal-800 hover:text-teal-950 hover:underline focus-visible:outline-2 focus-visible:outline-teal-700"
                    >
                        View all leads <ArrowRight size={14} />
                    </button>
                )}
            </footer>
        </Card>
    );
}
