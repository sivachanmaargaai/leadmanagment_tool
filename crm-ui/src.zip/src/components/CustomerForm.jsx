import { useState } from "react";
import { Plus, Save, Trash2 } from "lucide-react";
import { divisions } from "../data/crm";
import { readStaff } from "../lib/followUps";
import Modal from "./Modal";
import ReferralFields from "./ReferralFields";
import { Button, IconButton } from "./ui";

const inputClass =
    "min-w-0 w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-base text-slate-950 outline-none placeholder:text-slate-500 focus:border-teal-600 focus:ring-2 focus:ring-teal-100 sm:text-sm";

function Field({ label, children, wide = false }) {
    return (
        <label
            className={`flex min-w-0 flex-col gap-2 text-xs font-semibold text-slate-800 ${wide ? "sm:col-span-2" : ""
                }`}
        >
            {label}
            {children}
        </label>
    );
}

function emptyContact() {
    return { name: "", designation: "", phone: "", email: "" };
}

export default function CustomerForm({
    customer,
    onSave,
    onClose,
}) {
    const [form, setForm] = useState(() => ({
        name: customer?.name || "",
        type: customer?.type || "Company",
        address: customer?.address || "",
        city: customer?.city || "",
        state: customer?.state || "",
        postcode: customer?.postcode || "",
        gst: customer?.gst || "",
        assignedTo: customer?.assignedTo || "Admin",
        notes: customer?.notes || "",
    }));

    const [contacts, setContacts] = useState(() =>
        customer?.contacts?.length
            ? customer.contacts.map((contact) => ({ ...contact }))
            : [emptyContact()]
    );

    const [selectedDivisions, setSelectedDivisions] = useState(
        customer?.divisions || []
    );

    const [staff] = useState(readStaff);
    const [error, setError] = useState("");

    function bind(field) {
        return {
            value: form[field],
            onChange: (event) =>
                setForm((current) => ({
                    ...current,
                    [field]: event.target.value,
                })),
        };
    }

    function updateContact(index, field, value) {
        setContacts((current) =>
            current.map((contact, position) =>
                position === index ? { ...contact, [field]: value } : contact
            )
        );
    }

    function toggleDivision(name) {
        setSelectedDivisions((current) =>
            current.includes(name)
                ? current.filter((division) => division !== name)
                : [...current, name]
        );
    }

    function submit(event) {
        event.preventDefault();
        setError("");

        try {
            const name = form.name.trim();

            if (!name) throw new Error("Enter the customer/company name.");

            const cleanedContacts = contacts.map((contact) =>
                Object.fromEntries(
                    Object.entries(contact).map(([key, value]) => [
                        key,
                        String(value).trim(),
                    ])
                )
            );

            if (!cleanedContacts[0].phone && !cleanedContacts[0].email) {
                throw new Error("Enter a primary phone number or email address.");
            }

            if (!selectedDivisions.length) {
                throw new Error("Select at least one division.");
            }

            const data = new FormData(event.currentTarget);
            const source = String(data.get("leadSource"));
            const hasReference = ["Referral", "Known Network"].includes(source);
            const referenceId = String(data.get("referredById") || "");

            if (hasReference && !referenceId) {
                throw new Error("Select or add a reference contact.");
            }

            const at = new Date().toISOString();

            onSave({
                ...customer,
                ...Object.fromEntries(
                    Object.entries(form).map(([key, value]) => [key, value.trim()])
                ),
                id: customer?.id || crypto.randomUUID(),
                name,
                contacts: cleanedContacts,
                divisions: selectedDivisions,
                // Retain links to older leads/documents after a name change.
                aliases: [
                    ...new Set([
                        ...(customer?.aliases || []),
                        ...(customer?.name && customer.name !== name
                            ? [customer.name]
                            : []),
                    ]),
                ],
                leadSource: source,
                referredBy: hasReference
                    ? {
                        id: referenceId,
                        name: String(data.get("referredByName") || ""),
                        company: String(data.get("referredByCompany") || ""),
                        phone: String(data.get("referredByPhone") || ""),
                        email: String(data.get("referredByEmail") || ""),
                    }
                    : null,
                referenceNotes: hasReference
                    ? String(data.get("referenceNotes") || "").trim()
                    : "",
                createdAt: customer?.createdAt || at,
                updatedAt: at,
                history: [
                    ...(customer?.history || []),
                    {
                        id: crypto.randomUUID(),
                        at,
                        message: customer
                            ? "Customer profile updated."
                            : "Customer profile created.",
                    },
                ],
            });
        } catch (saveError) {
            setError(saveError.message || "Could not save the customer.");
        }
    }

    return (
        <Modal
            title={customer ? "Edit customer" : "Add customer"}
            onClose={onClose}
        >
            <form onSubmit={submit}>
                <div className="space-y-5 p-4 sm:p-5">
                    <div className="grid gap-4 sm:grid-cols-2">
                        <Field label="Customer / company name *">
                            <input
                                required
                                autoFocus
                                maxLength={120}
                                className={inputClass}
                                {...bind("name")}
                            />
                        </Field>

                        <Field label="Customer type">
                            <select className={inputClass} {...bind("type")}>
                                <option>Company</option>
                                <option>Individual</option>
                            </select>
                        </Field>
                    </div>

                    <fieldset>
                        <legend className="mb-3 text-xs font-semibold text-slate-800">
                            Associated divisions *
                        </legend>

                        <div className="flex flex-wrap gap-2">
                            {divisions.map((division) => (
                                <label
                                    key={division}
                                    className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold ${selectedDivisions.includes(division)
                                        ? "border-teal-700 bg-teal-50 text-teal-950"
                                        : "border-slate-300 text-slate-700"
                                        }`}
                                >
                                    <input
                                        type="checkbox"
                                        checked={selectedDivisions.includes(division)}
                                        onChange={() => toggleDivision(division)}
                                        className="accent-teal-800"
                                    />
                                    {division}
                                </label>
                            ))}
                        </div>
                    </fieldset>

                    <div>
                        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                            <h3 className="text-sm font-bold text-slate-950">
                                Contact people
                            </h3>

                            <Button
                                variant="secondary"
                                onClick={() =>
                                    setContacts((current) => [...current, emptyContact()])
                                }
                            >
                                <Plus size={15} /> Add contact
                            </Button>
                        </div>

                        <div className="space-y-3">
                            {contacts.map((contact, index) => (
                                <div
                                    key={index}
                                    className="rounded-xl border border-slate-200 bg-slate-50 p-3 shadow-sm"
                                >
                                    <div className="mb-3 flex items-center justify-between">
                                        <strong className="text-xs text-slate-900">
                                            {index === 0 ? "Primary contact" : `Contact ${index + 1}`}
                                        </strong>

                                        {index > 0 && (
                                            <IconButton
                                                aria-label={`Remove contact ${index + 1}`}
                                                onClick={() =>
                                                    setContacts((current) =>
                                                        current.filter((_, position) => position !== index)
                                                    )
                                                }
                                            >
                                                <Trash2 size={15} />
                                            </IconButton>
                                        )}
                                    </div>

                                    <div className="grid gap-3 sm:grid-cols-2">
                                        {[
                                            ["name", "Contact name", "text"],
                                            ["designation", "Designation", "text"],
                                            ["phone", "Phone", "tel"],
                                            ["email", "Email", "email"],
                                        ].map(([field, label, type]) => (
                                            <Field key={field} label={label}>
                                                <input
                                                    type={type}
                                                    maxLength={120}
                                                    value={contact[field] || ""}
                                                    onChange={(event) =>
                                                        updateContact(index, field, event.target.value)
                                                    }
                                                    className={inputClass}
                                                />
                                            </Field>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="grid gap-4 sm:grid-cols-2">
                        <Field label="Address" wide>
                            <textarea
                                rows={2}
                                maxLength={500}
                                className={`${inputClass} resize-y`}
                                {...bind("address")}
                            />
                        </Field>

                        {[
                            ["city", "City"],
                            ["state", "State"],
                            ["postcode", "Postcode"],
                            ["gst", "GST number — optional"],
                        ].map(([field, label]) => (
                            <Field key={field} label={label}>
                                <input
                                    maxLength={100}
                                    className={inputClass}
                                    {...bind(field)}
                                />
                            </Field>
                        ))}

                        <Field label="Responsible staff">
                            <input
                                list="customer-staff"
                                maxLength={80}
                                className={inputClass}
                                {...bind("assignedTo")}
                            />
                            <datalist id="customer-staff">
                                {staff.map((name) => (
                                    <option key={name} value={name} />
                                ))}
                            </datalist>
                        </Field>

                        <ReferralFields
                            initialSource={customer?.leadSource || "Direct Enquiry"}
                            initialReference={customer?.referredBy || null}
                            initialNotes={customer?.referenceNotes || ""}
                        />

                        <Field label="Internal notes" wide>
                            <textarea
                                rows={3}
                                maxLength={2000}
                                className={`${inputClass} resize-y`}
                                {...bind("notes")}
                            />
                        </Field>
                    </div>

                    {error && (
                        <p
                            role="alert"
                            className="rounded-lg bg-rose-50 p-3 text-xs text-rose-900"
                        >
                            {error}
                        </p>
                    )}
                </div>

                <footer className="flex justify-end gap-3 border-t border-slate-200 bg-slate-50 px-4 py-3">
                    <Button variant="secondary" onClick={onClose}>
                        Cancel
                    </Button>
                    <Button type="submit">
                        <Save size={16} /> Save customer
                    </Button>
                </footer>
            </form>
        </Modal>
    );
}