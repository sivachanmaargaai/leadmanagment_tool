import { useEffect, useState } from "react";
import { FOLLOW_UP_KEY } from "../lib/followUps";

function load() {
  const raw = localStorage.getItem(FOLLOW_UP_KEY);
  const records = raw ? JSON.parse(raw) : [];
  if (!Array.isArray(records) || records.some((item) => !item.id || !item.leadId || !Number.isFinite(Date.parse(item.dueAt)))) {
    throw new Error("Saved follow-up data could not be read. Existing data has been retained.");
  }
  return records;
}

export default function useFollowUps() {
  const [state, setState] = useState(() => {
    try { return { records: load(), error: "" }; }
    catch (error) { return { records: [], error: error.message }; }
  });
  const [now, setNow] = useState(Date.now);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30000);
    function sync(event) {
      if (event.key !== FOLLOW_UP_KEY && event.key !== null) return;
      try { setState({ records: load(), error: "" }); }
      catch (error) { setState((current) => ({ ...current, error: error.message })); }
    }
    window.addEventListener("storage", sync);
    return () => { clearInterval(timer); window.removeEventListener("storage", sync); };
  }, []);

  function save(updater) {
    // Read before writing to retain changes from another open tab.
    const current = load();
    const records = updater(current);
    localStorage.setItem(FOLLOW_UP_KEY, JSON.stringify(records));
    setState({ records, error: "" });
    setNow(Date.now());
  }

  return { followUps: state.records, error: state.error, saveFollowUps: save, now };
}
