import { useEffect, useRef, useState } from "react";
import {
    Plus,
    Upload,
    Eye,
    Download,
    Search,
    FileText,
} from "lucide-react";
import { divisions } from "../data/crm";
import {
    Button,
    Card,
    CardHeading,
    EmptyState,
    IconButton,
} from "../components/ui";
import QuoteDialog from "../components/quotations/QuoteDialog";
import QuoteForm from "../components/quotations/QuoteForm";
import { getQuotations, saveQuotation } from "../lib/quotationDb";
import {
    billingTypes,
    quoteStatuses,
    money,
    effectiveStatus,
    downloadPdf,
    validatePdf,
} from "../lib/quotationPdf";

const selectClass =
    "rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100";

function PdfViewer({ quotation, onClose }) {
    const [versionIndex, setVersionIndex] = useState(
        quotation.versions.length - 1
    );
    const [url, setUrl] = useState("");
    const version = quotation.versions[versionIndex];

    useEffect(() => {
        const objectUrl = URL.createObjectURL(version.file);
        setUrl(objectUrl);

        return () => URL.revokeObjectURL(objectUrl);
    }, [version]);

    return (
        <QuoteDialog
            title={`${quotation.number} · ${quotation.customer}`}
            onClose={onClose}
        >
            <div className="flex flex-wrap items-center justify-between gap-3 p-4">
                <label className="flex items-center gap-3 text-xs font-semibold">
                    Version
                    <select
                        value={versionIndex}
                        onChange={(event) => setVersionIndex(Number(event.target.value))}
                        className={selectClass}
                    >
                        {quotation.versions.map((entry, index) => (
                            <option key={entry.id} value={index}>
                                Revision {index + 1}
                                {index === quotation.versions.length - 1 ? " — Latest" : ""}
                            </option>
                        ))}
                    </select>
                </label>

                <Button
                    variant="secondary"
                    onClick={() => downloadPdf(version)}
                >
                    <Download size={16} /> Download PDF
                </Button>
            </div>

            <p className="break-words px-4 pb-3 text-xs text-slate-700">
                {version.name} ·{" "}
                {new Date(version.uploadedAt).toLocaleString("en-IN", {
                    timeZone: "Asia/Kolkata",
                })}
            </p>

            {url && (
                <object
                    key={url}
                    data={url}
                    type="application/pdf"
                    aria-label={`PDF preview for ${quotation.number}`}
                    className="block h-[65dvh] w-full border-t border-slate-200 bg-slate-100"
                >
                    <div className="p-8 text-center">
                        <p className="mb-4 text-sm text-slate-800">
                            This browser cannot show an embedded PDF.
                        </p>
                        <Button onClick={() => downloadPdf(version)}>
                            Download PDF
                        </Button>
                    </div>
                </object>
            )}
        </QuoteDialog>
    );
}

export default function Quotations({ leads = [] }) {
    const [quotations, setQuotations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [notice, setNotice] = useState("");
    const [mode, setMode] = useState(null);
    const [preview, setPreview] = useState(null);
    const [search, setSearch] = useState("");
    const [division, setDivision] = useState("All divisions");
    const [status, setStatus] = useState("All statuses");
    const [busyId, setBusyId] = useState(null);

    const revisionInput = useRef(null);
    const revisionTarget = useRef(null);

    useEffect(() => {
        let active = true;

        getQuotations()
            .then((records) => {
                if (active) {
                    setQuotations(
                        records.sort((a, b) => b.createdAt.localeCompare(a.createdAt))
                    );
                }
            })
            .catch((loadError) => {
                if (active) setError(loadError.message);
            })
            .finally(() => {
                if (active) setLoading(false);
            });

        return () => {
            active = false;
        };
    }, []);

    const divisionQuotes = quotations.filter(
        (quote) => division === "All divisions" || quote.division === division
    );

    const filtered = divisionQuotes.filter((quote) => {
        const matchesStatus =
            status === "All statuses" || effectiveStatus(quote) === status;

        const matchesSearch = `${quote.number} ${quote.customer} ${quote.division}`
            .toLowerCase()
            .includes(search.trim().toLowerCase());

        return matchesStatus && matchesSearch;
    });

    async function addQuotation(quotation) {
        await saveQuotation(quotation);

        setQuotations((current) => [quotation, ...current]);
        setMode(null);
        setNotice("Quotation and PDF saved in this browser.");
    }

    async function changeStatus(quotation, nextStatus) {
        setBusyId(quotation.id);
        setError("");
        setNotice("");

        try {
            const updated = { ...quotation, status: nextStatus };
            await saveQuotation(updated);

            setQuotations((current) =>
                current.map((quote) =>
                    quote.id === updated.id ? updated : quote
                )
            );

            setNotice("Status updated. The PDF document remains unchanged.");
        } catch (saveError) {
            setError(saveError.message);
        } finally {
            setBusyId(null);
        }
    }

    async function uploadRevision(event) {
        const file = event.target.files?.[0];
        const quotation = revisionTarget.current;

        event.target.value = "";

        if (!file || !quotation) return;

        setBusyId(quotation.id);
        setError("");
        setNotice("");

        try {
            await validatePdf(file);

            const updated = {
                ...quotation,
                status: "Draft",
                versions: [
                    ...quotation.versions,
                    {
                        id: crypto.randomUUID(),
                        name: file.name,
                        file,
                        uploadedAt: new Date().toISOString(),
                    },
                ],
            };

            await saveQuotation(updated);

            setQuotations((current) =>
                current.map((quote) =>
                    quote.id === updated.id ? updated : quote
                )
            );

            setNotice(
                "Revision saved. Previous PDFs retained; status reset to Draft. Existing amount and dates retained."
            );
        } catch (uploadError) {
            setError(uploadError.message);
        } finally {
            setBusyId(null);
            revisionTarget.current = null;
        }
    }

    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
                <p className="max-w-xl text-xs leading-6 text-slate-700">
                    Create quotations or keep existing PDFs in one place.
                    Files are stored in this browser, on this device.
                </p>

                <div className="flex flex-wrap gap-3">
                    <Button
                        variant="secondary"
                        disabled={loading}
                        onClick={() => setMode("upload")}
                    >
                        <Upload size={16} /> Upload PDF
                    </Button>
                    <Button
                        disabled={loading}
                        onClick={() => setMode("create")}
                    >
                        <Plus size={16} /> Create quotation
                    </Button>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
                {["Total", "Draft", "Sent", "Accepted", "Expired"].map((label) => (
                    <Card key={label} className="p-4">
                        <p className="text-xs font-semibold text-slate-700">
                            {label === "Total" ? "Total quotations" : label}
                        </p>
                        <strong className="mt-2 block text-2xl font-bold text-slate-950">
                            {label === "Total"
                                ? divisionQuotes.length
                                : divisionQuotes.filter(
                                    (quote) => effectiveStatus(quote) === label
                                ).length}
                        </strong>
                    </Card>
                ))}
            </div>

            {error && (
                <p
                    role="alert"
                    className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-900"
                >
                    {error}
                </p>
            )}

            {notice && (
                <p
                    role="status"
                    className="rounded-xl border border-teal-200 bg-teal-50 p-4 text-xs leading-6 text-teal-950"
                >
                    {notice}
                </p>
            )}

            <Card>
                <CardHeading
                    title="Quotation register"
                    description="Your documents, statuses and revision history."
                />

                <div className="flex flex-wrap gap-3 border-t border-slate-100 px-5 py-4">
                    <label className="flex min-w-44 flex-1 items-center gap-2 rounded-lg border border-slate-300 px-3 py-2 focus-within:ring-2 focus-within:ring-teal-100">
                        <Search size={16} className="text-slate-700" />
                        <input
                            aria-label="Search quotations"
                            placeholder="Search customer or quotation number..."
                            value={search}
                            onChange={(event) => setSearch(event.target.value)}
                            className="w-full bg-transparent text-xs text-slate-950 outline-none placeholder:text-slate-500"
                        />
                    </label>

                    <select
                        aria-label="Filter by division"
                        value={division}
                        onChange={(event) => setDivision(event.target.value)}
                        className={selectClass}
                    >
                        <option>All divisions</option>
                        {divisions.map((name) => (
                            <option key={name}>{name}</option>
                        ))}
                    </select>

                    <select
                        aria-label="Filter by status"
                        value={status}
                        onChange={(event) => setStatus(event.target.value)}
                        className={selectClass}
                    >
                        <option>All statuses</option>
                        {quoteStatuses.map((name) => (
                            <option key={name}>{name}</option>
                        ))}
                    </select>
                </div>

                {loading ? (
                    <p className="p-10 text-center text-sm text-slate-700">
                        Loading quotations...
                    </p>
                ) : filtered.length === 0 ? (
                    <EmptyState
                        icon={FileText}
                        title="No quotations found"
                        description="Create a quotation, upload a PDF, or adjust your filters."
                    />
                ) : (
                    <>
                    <div className="grid gap-3 px-3 pb-3 sm:grid-cols-2 lg:hidden">
                        {filtered.map((quote) => <article key={quote.id} className="min-w-0 rounded-xl border border-slate-200 p-3 shadow-sm shadow-slate-900/5">
                            <div className="flex flex-wrap items-start justify-between gap-2">
                                <div className="min-w-0"><strong className="block break-words text-sm text-slate-950">{quote.customer}</strong><p className="mt-1 break-all text-[11px] font-medium text-teal-800">{quote.number}</p></div>
                                <select aria-label={`Status for ${quote.number}`} value={effectiveStatus(quote)} disabled={busyId === quote.id} onChange={(event) => changeStatus(quote, event.target.value)} className={selectClass}>{quoteStatuses.map((name) => <option key={name}>{name}</option>)}</select>
                            </div>
                            <dl className="mt-3 space-y-1.5 text-[11px] text-slate-700"><div className="flex justify-between gap-3"><dt>Division</dt><dd className="font-semibold text-slate-900">{quote.division}</dd></div><div className="flex justify-between gap-3"><dt>Valid until</dt><dd>{quote.validUntil}</dd></div></dl>
                            <div className="my-3 rounded-lg bg-teal-50 p-2.5">{billingTypes.filter((billing) => quote.totals[billing]).map((billing) => <p key={billing} className="flex flex-wrap justify-between gap-2 text-xs leading-6 text-teal-950"><span>{billing}</span><strong>{money(quote.totals[billing].total, quote.currency)}</strong></p>)}</div>
                            <div className="flex items-center justify-between gap-2 border-t border-slate-100 pt-2"><span className="text-[10px] text-slate-600">{quote.versions.length} version(s)</span><div className="flex gap-1">
                                <IconButton aria-label={`View ${quote.number}`} onClick={() => setPreview(quote)}><Eye size={17} /></IconButton>
                                <IconButton aria-label={`Download ${quote.number}`} onClick={() => downloadPdf(quote.versions.at(-1))}><Download size={17} /></IconButton>
                                <IconButton aria-label={`Upload revision for ${quote.number}`} disabled={busyId === quote.id} onClick={() => { revisionTarget.current = quote; revisionInput.current.click(); }}><Upload size={17} /></IconButton>
                            </div></div>
                        </article>)}
                    </div>
                    <div className="hidden overflow-x-auto lg:block">
                        <table className="w-full whitespace-nowrap text-left">
                            <thead className="border-y border-slate-200 bg-slate-50 text-[10px] uppercase tracking-wide text-slate-700">
                                <tr>
                                    {[
                                        "Quotation",
                                        "Customer",
                                        "Division",
                                        "Dates",
                                        "Amount",
                                        "Status",
                                        "Actions",
                                    ].map((heading) => (
                                        <th key={heading} className="px-5 py-3">
                                            {heading}
                                        </th>
                                    ))}
                                </tr>
                            </thead>

                            <tbody className="divide-y divide-slate-100">
                                {filtered.map((quote) => (
                                    <tr
                                        key={quote.id}
                                        className="text-xs text-slate-800 transition-colors hover:bg-teal-50/40"
                                    >
                                        <td className="px-5 py-4">
                                            <strong className="block text-slate-950">
                                                {quote.number}
                                            </strong>
                                            <small className="mt-1 block text-slate-600">
                                                {quote.source} · {quote.versions.length} version(s)
                                            </small>
                                        </td>

                                        <td className="px-5 py-4 font-medium">
                                            {quote.customer}
                                        </td>

                                        <td className="px-5 py-4">{quote.division}</td>

                                        <td className="px-5 py-4">
                                            <span className="block">{quote.date}</span>
                                            <small className="mt-1 block text-slate-600">
                                                Valid: {quote.validUntil}
                                            </small>
                                        </td>

                                        <td className="px-5 py-4">
                                            {billingTypes
                                                .filter((billing) => quote.totals[billing])
                                                .map((billing) => (
                                                    <span key={billing} className="block leading-6">
                                                        {money(quote.totals[billing].total, quote.currency)}
                                                        <small className="ml-1 text-slate-600">
                                                            {billing === "One-time"
                                                                ? "once"
                                                                : billing === "Monthly"
                                                                    ? "/ month"
                                                                    : "/ year"}
                                                        </small>
                                                    </span>
                                                ))}
                                        </td>

                                        <td className="px-5 py-4">
                                            <select
                                                aria-label={`Status for ${quote.number}`}
                                                value={effectiveStatus(quote)}
                                                disabled={busyId === quote.id}
                                                onChange={(event) =>
                                                    changeStatus(quote, event.target.value)
                                                }
                                                className={selectClass}
                                            >
                                                {quoteStatuses.map((name) => (
                                                    <option key={name}>{name}</option>
                                                ))}
                                            </select>
                                        </td>

                                        <td className="px-5 py-4">
                                            <div className="flex gap-1">
                                                <IconButton
                                                    aria-label={`View ${quote.number}`}
                                                    title="View PDF & history"
                                                    onClick={() => setPreview(quote)}
                                                >
                                                    <Eye size={17} />
                                                </IconButton>

                                                <IconButton
                                                    aria-label={`Download ${quote.number}`}
                                                    title="Download latest PDF"
                                                    onClick={() =>
                                                        downloadPdf(quote.versions.at(-1))
                                                    }
                                                >
                                                    <Download size={17} />
                                                </IconButton>

                                                <IconButton
                                                    aria-label={`Upload revision for ${quote.number}`}
                                                    title="Upload revision"
                                                    disabled={busyId === quote.id}
                                                    onClick={() => {
                                                        revisionTarget.current = quote;
                                                        revisionInput.current.click();
                                                    }}
                                                >
                                                    <Upload size={17} />
                                                </IconButton>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    </>
                )}

                <footer className="border-t border-slate-200 px-5 py-4 text-xs text-slate-600">
                    {filtered.length} matching quotation(s)
                </footer>
            </Card>

            <input
                ref={revisionInput}
                type="file"
                accept=".pdf,application/pdf"
                aria-label="Upload quotation revision"
                className="hidden"
                onChange={uploadRevision}
            />

            {mode && (
                <QuoteForm
                    mode={mode}
                    leads={leads}
                    onClose={() => setMode(null)}
                    onSave={addQuotation}
                />
            )}

            {preview && (
                <PdfViewer quotation={preview} onClose={() => setPreview(null)} />
            )}
        </div>
    );
}
