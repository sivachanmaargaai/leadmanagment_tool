import { useState } from "react";
import {
    UserRound,
    Building2,
    Users,
    SlidersHorizontal,
    FileText,
    Bell,
    PanelsTopLeft,
    Save,
    Plus,
    Check,
} from "lucide-react";
import { Button, Card } from "../components/ui";
import { divisions } from "../data/crm";

const STORAGE_KEY = "engen-crm-settings";

const tabs = [
    { id: "profile", label: "My profile", icon: UserRound },
    { id: "company", label: "Company & divisions", icon: Building2 },
    { id: "users", label: "Users & access", icon: Users },
    { id: "leads", label: "Lead settings", icon: SlidersHorizontal },
    { id: "quotation", label: "Products & quotations", icon: FileText },
    { id: "notifications", label: "Notifications", icon: Bell },
    { id: "workspace", label: "Workspace", icon: PanelsTopLeft },
];

const defaults = {
    profile: {
        name: "Admin",
        email: "",
        phone: "",
        designation: "Administrator",
    },
    company: {
        name: "ENGEN",
        email: "",
        phone: "",
        address: "",
        gst: "",
        website: "",
    },
    divisions: Object.fromEntries(
        divisions.map((name) => [
            name,
            {
                name,
                address: "",
                gst: "",
                prefix: name === "MMC" ? "MMC" : name === "Nemilinks" ? "NEM" : "CCL",
            },
        ])
    ),
    users: [
        {
            id: "admin",
            name: "Admin",
            email: "",
            role: "Admin",
            active: true,
        },
    ],
    leads: {
        defaultPriority: "Medium",
        defaultStatus: "New",
        sources: "Website, Referral, Phone, Email, Exhibition",
        followUpDays: "2",
        requireContact: false,
        requireDescription: true,
    },
    quotation: {
        prefix: "ENG",
        nextNumber: "1001",
        currency: "INR",
        validity: "15",
        tax: "",
        paymentTerms: "",
        warranty: "",
        notes: "",
        showLogo: true,
        showSignature: true,
        approvalRequired: false,
    },
    notifications: {
        leadAssigned: true,
        followUp: true,
        overdue: true,
        quotationExpiry: true,
        reminderBefore: "30",
        sound: false,
    },
    workspace: {
        sidebar: "Hover to expand",
        defaultDivision: "All divisions",
        rowsPerPage: "10",
        dateFormat: "DD MMM YYYY",
    },
};

function loadSettings() {
    try {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));

        if (!stored || typeof stored !== "object") {
            return structuredClone(defaults);
        }

        return Object.fromEntries(
            Object.entries(defaults).map(([key, value]) => [
                key,
                Array.isArray(value)
                    ? Array.isArray(stored[key])
                        ? stored[key]
                        : value
                    : { ...value, ...stored[key] },
            ])
        );
    } catch {
        return structuredClone(defaults);
    }
}

const inputClass =
    "min-w-0 w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-950 outline-none transition placeholder:text-slate-500 focus:border-teal-600 focus:ring-2 focus:ring-teal-100";

function Field({ label, hint, className = "", ...props }) {
    return (
        <label className={`block min-w-0 ${className}`}>
            <span className="mb-2 block text-xs font-semibold text-slate-800">
                {label}
            </span>
            <input className={inputClass} {...props} />
            {hint && (
                <span className="mt-2 block text-xs leading-5 text-slate-600">
                    {hint}
                </span>
            )}
        </label>
    );
}

function Select({ label, options, ...props }) {
    return (
        <label className="block min-w-0">
            <span className="mb-2 block text-xs font-semibold text-slate-800">
                {label}
            </span>
            <select className={inputClass} {...props}>
                {options.map((option) => (
                    <option key={option}>{option}</option>
                ))}
            </select>
        </label>
    );
}

function TextArea({ label, ...props }) {
    return (
        <label className="block min-w-0">
            <span className="mb-2 block text-xs font-semibold text-slate-800">
                {label}
            </span>
            <textarea
                className={`${inputClass} resize-y`}
                rows={3}
                {...props}
            />
        </label>
    );
}

function Toggle({ label, description, checked, onChange }) {
    return (
        <div className="flex items-center justify-between gap-5 border-b border-slate-100 py-4 last:border-0">
            <div>
                <strong className="block text-sm font-semibold text-slate-900">
                    {label}
                </strong>
                {description && (
                    <p className="mt-1 text-xs leading-5 text-slate-600">
                        {description}
                    </p>
                )}
            </div>

            <button
                type="button"
                role="switch"
                aria-checked={checked}
                aria-label={label}
                onClick={() => onChange(!checked)}
                className={`inline-flex h-6 w-11 shrink-0 items-center rounded-full p-1 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 ${checked ? "bg-teal-800" : "bg-slate-300"
                    }`}
            >
                <span
                    className={`size-4 rounded-full bg-white shadow-sm transition-transform ${checked ? "translate-x-5" : "translate-x-0"
                        }`}
                />
            </button>
        </div>
    );
}

function Section({ title, description, children }) {
    return (
        <div>
            <h2 className="text-lg font-bold text-slate-950">{title}</h2>
            <p className="mb-4 mt-1.5 text-xs leading-5 text-slate-700">
                {description}
            </p>
            {children}
        </div>
    );
}

export default function Settings() {
    const [tab, setTab] = useState("profile");
    const [settings, setSettings] = useState(loadSettings);
    const [selectedDivision, setSelectedDivision] = useState(divisions[0]);
    const [notice, setNotice] = useState("");
    const [newUser, setNewUser] = useState({ name: "", email: "" });

    function update(section, field, value) {
        setSettings((current) => ({
            ...current,
            [section]: { ...current[section], [field]: value },
        }));
        setNotice("");
    }

    function bind(section, field) {
        return {
            value: settings[section][field],
            onChange: (event) => update(section, field, event.target.value),
        };
    }

    function toggle(section, field) {
        return {
            checked: settings[section][field],
            onChange: (value) => update(section, field, value),
        };
    }

    function updateDivision(field, value) {
        setSettings((current) => ({
            ...current,
            divisions: {
                ...current.divisions,
                [selectedDivision]: {
                    ...current.divisions[selectedDivision],
                    [field]: value,
                },
            },
        }));
        setNotice("");
    }

    function updateUser(id, field, value) {
        setSettings((current) => ({
            ...current,
            users: current.users.map((user) =>
                user.id === id ? { ...user, [field]: value } : user
            ),
        }));
        setNotice("");
    }

    function addUser() {
        const name = newUser.name.trim();
        const email = newUser.email.trim();

        if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            setNotice("Enter a staff name and valid email.");
            return;
        }

        if (
            settings.users.some(
                (user) => user.email.toLowerCase() === email.toLowerCase()
            )
        ) {
            setNotice("This email is already listed.");
            return;
        }

        setSettings((current) => ({
            ...current,
            users: [
                ...current.users,
                {
                    id: crypto.randomUUID(),
                    name,
                    email,
                    role: "Staff",
                    active: true,
                },
            ],
        }));

        setNewUser({ name: "", email: "" });
        setNotice("Staff entry added. Save to keep your changes.");
    }

    function saveSettings(event) {
        event.preventDefault();

        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
            setNotice("Settings saved in this browser.");
        } catch {
            setNotice("Could not save. Browser storage may be unavailable.");
        }
    }

    const divisionSettings = {
        ...defaults.divisions[selectedDivision],
        ...settings.divisions[selectedDivision],
    };

    return (
        <div className="grid min-w-0 items-start gap-4 lg:grid-cols-[210px_minmax(0,1fr)]">
            {/* Settings navigation */}
            <Card className="min-w-0 p-2 lg:sticky lg:top-4">
                <p className="px-3 pb-3 pt-2 text-[10px] font-bold tracking-widest text-slate-600">
                    SETTINGS
                </p>

                <nav className="flex gap-1 overflow-x-auto pb-1 lg:block lg:space-y-1 lg:overflow-visible lg:pb-0" aria-label="Settings sections">
                    {tabs.map(({ id, label, icon: Icon }) => (
                        <button
                            key={id}
                            type="button"
                            aria-current={tab === id ? "page" : undefined}
                            onClick={() => {
                                setTab(id);
                                setNotice("");
                            }}
                            className={`flex shrink-0 items-center gap-2 whitespace-nowrap rounded-xl px-3 py-2.5 text-left text-xs lg:w-full font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-teal-700 ${tab === id
                                ? "bg-teal-900 text-white"
                                : "text-slate-700 hover:bg-teal-50 hover:text-teal-950"
                                }`}
                        >
                            <Icon size={17} />
                            {label}
                        </button>
                    ))}
                </nav>
            </Card>

            {/* Settings content */}
            <Card>
                <form onSubmit={saveSettings}>
                    <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-xs leading-6 text-amber-950">
                        UI prototype: settings save in this browser. Account access,
                        reminders and business rules connect with the backend later.
                    </div>

                    <div className="min-w-0 p-4 sm:p-5">
                        {tab === "profile" && (
                            <Section
                                title="My profile"
                                description="Your contact details and workspace identity."
                            >
                                <div className="grid gap-4 sm:grid-cols-2">
                                    <Field label="Full name" {...bind("profile", "name")} />
                                    <Field
                                        label="Email address"
                                        type="email"
                                        {...bind("profile", "email")}
                                    />
                                    <Field
                                        label="Phone number"
                                        type="tel"
                                        {...bind("profile", "phone")}
                                    />
                                    <Field
                                        label="Designation"
                                        {...bind("profile", "designation")}
                                    />
                                </div>

                                <p className="mt-6 rounded-lg bg-slate-50 p-4 text-xs leading-6 text-slate-700">
                                    Password changes will be available after real login is
                                    connected.
                                </p>
                            </Section>
                        )}

                        {tab === "company" && (
                            <Section
                                title="Company & divisions"
                                description="Manage parent company details and division-specific quotation information."
                            >
                                <div className="mb-4 flex flex-wrap items-center gap-4 rounded-xl border border-slate-200 p-4">
                                    <img
                                        src={`${import.meta.env.BASE_URL}Engen%20logo%20Final.png`}
                                        alt="ENGEN"
                                        className="h-auto w-32 object-contain"
                                    />
                                    <p className="text-xs leading-6 text-slate-700">
                                        Current workspace logo
                                        <br />
                                        ENGEN · Scaling Heights
                                    </p>
                                </div>

                                <div className="grid gap-4 sm:grid-cols-2">
                                    <Field label="Company name" {...bind("company", "name")} />
                                    <Field label="Website" {...bind("company", "website")} />
                                    <Field
                                        label="Company email"
                                        type="email"
                                        {...bind("company", "email")}
                                    />
                                    <Field
                                        label="Phone"
                                        type="tel"
                                        {...bind("company", "phone")}
                                    />
                                    <Field
                                        label="GST number"
                                        {...bind("company", "gst")}
                                        className="sm:col-span-2"
                                    />
                                </div>

                                <div className="mt-5">
                                    <TextArea
                                        label="Company address"
                                        {...bind("company", "address")}
                                    />
                                </div>

                                <div className="mt-8 border-t border-slate-200 pt-6">
                                    <h3 className="mb-5 text-sm font-bold text-slate-950">
                                        Division details
                                    </h3>

                                    <Select
                                        label="Select division"
                                        options={divisions}
                                        value={selectedDivision}
                                        onChange={(event) =>
                                            setSelectedDivision(event.target.value)
                                        }
                                    />

                                    <div className="mt-5 grid gap-4 sm:grid-cols-2">
                                        <Field
                                            label="GST number"
                                            value={divisionSettings.gst}
                                            onChange={(event) =>
                                                updateDivision("gst", event.target.value)
                                            }
                                        />
                                        <Field
                                            label="Quotation prefix"
                                            value={divisionSettings.prefix}
                                            onChange={(event) =>
                                                updateDivision("prefix", event.target.value)
                                            }
                                        />
                                    </div>

                                    <div className="mt-5">
                                        <TextArea
                                            label="Division address"
                                            value={divisionSettings.address}
                                            onChange={(event) =>
                                                updateDivision("address", event.target.value)
                                            }
                                        />
                                    </div>
                                </div>
                            </Section>
                        )}

                        {tab === "users" && (
                            <Section
                                title="Users & access"
                                description="Prepare your team list and roles. These entries do not create login accounts yet."
                            >
                                <div className="space-y-3">
                                    {settings.users.map((user) => (
                                        <div
                                            key={user.id}
                                            className="flex flex-wrap items-center gap-4 rounded-xl border border-slate-200 p-4"
                                        >
                                            <span className="flex size-10 items-center justify-center rounded-full bg-lime-100 text-sm font-bold text-teal-950">
                                                {user.name.charAt(0).toUpperCase()}
                                            </span>

                                            <div className="min-w-0 flex-1">
                                                <strong className="block text-sm text-slate-950">
                                                    {user.name}
                                                </strong>
                                                <small className="mt-1 block break-all text-xs text-slate-600">
                                                    {user.email || "Email not added"}
                                                </small>
                                            </div>

                                            {user.id === "admin" ? (
                                                <span className="rounded-md bg-teal-50 px-3 py-1.5 text-xs font-semibold text-teal-900">
                                                    Admin
                                                </span>
                                            ) : (
                                                <>
                                                    <select
                                                        aria-label={`Role for ${user.name}`}
                                                        value={user.role}
                                                        onChange={(event) =>
                                                            updateUser(user.id, "role", event.target.value)
                                                        }
                                                        className="rounded-lg border border-slate-300 px-2 py-2 text-xs text-slate-900"
                                                    >
                                                        <option>Staff</option>
                                                        <option>Admin</option>
                                                    </select>

                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            updateUser(user.id, "active", !user.active)
                                                        }
                                                        className={`rounded-lg px-3 py-2 text-xs font-semibold ${user.active
                                                            ? "bg-emerald-50 text-emerald-900 hover:bg-emerald-100"
                                                            : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                                                            }`}
                                                    >
                                                        {user.active ? "Active" : "Inactive"}
                                                    </button>
                                                </>
                                            )}
                                        </div>
                                    ))}
                                </div>

                                <div className="mt-7 rounded-xl bg-slate-50 p-4">
                                    <h3 className="mb-4 text-sm font-bold text-slate-950">
                                        Add staff entry
                                    </h3>

                                    <div className="grid gap-4 sm:grid-cols-2">
                                        <Field
                                            label="Staff name"
                                            value={newUser.name}
                                            onChange={(event) =>
                                                setNewUser((current) => ({
                                                    ...current,
                                                    name: event.target.value,
                                                }))
                                            }
                                        />
                                        <Field
                                            label="Email"
                                            type="email"
                                            value={newUser.email}
                                            onChange={(event) =>
                                                setNewUser((current) => ({
                                                    ...current,
                                                    email: event.target.value,
                                                }))
                                            }
                                        />
                                    </div>

                                    <Button
                                        variant="secondary"
                                        className="mt-4"
                                        onClick={addUser}
                                    >
                                        <Plus size={16} /> Add staff
                                    </Button>
                                </div>
                            </Section>
                        )}

                        {tab === "leads" && (
                            <Section
                                title="Lead settings"
                                description="Prepare default values and information requirements for new leads."
                            >
                                <div className="grid gap-4 sm:grid-cols-2">
                                    <Select
                                        label="Default priority"
                                        options={["High", "Medium", "Low"]}
                                        {...bind("leads", "defaultPriority")}
                                    />
                                    <Select
                                        label="Default status"
                                        options={["New", "In Progress", "Follow-up"]}
                                        {...bind("leads", "defaultStatus")}
                                    />
                                    <Field
                                        label="Default follow-up interval — days"
                                        type="number"
                                        min="1"
                                        {...bind("leads", "followUpDays")}
                                    />
                                </div>

                                <div className="my-5">
                                    <TextArea
                                        label="Lead sources — separated by commas"
                                        {...bind("leads", "sources")}
                                    />
                                </div>

                                <Toggle
                                    label="Require customer contact"
                                    description="A phone number or email must be provided."
                                    {...toggle("leads", "requireContact")}
                                />
                                <Toggle
                                    label="Require requirement description"
                                    description="Include a brief description of the enquiry."
                                    {...toggle("leads", "requireDescription")}
                                />
                            </Section>
                        )}

                        {tab === "quotation" && (
                            <Section
                                title="Products & quotations"
                                description="Defaults for embedded / IoT products, software and service quotations."
                            >
                                <div className="grid gap-4 sm:grid-cols-2">
                                    <Field
                                        label="Default quotation prefix"
                                        {...bind("quotation", "prefix")}
                                    />
                                    <Field
                                        label="Next quotation number"
                                        type="number"
                                        min="1"
                                        {...bind("quotation", "nextNumber")}
                                    />
                                    <Select
                                        label="Currency"
                                        options={["INR", "USD", "EUR"]}
                                        {...bind("quotation", "currency")}
                                    />
                                    <Field
                                        label="Validity — days"
                                        type="number"
                                        min="1"
                                        {...bind("quotation", "validity")}
                                    />
                                    <Field
                                        label="Default tax — %"
                                        type="number"
                                        min="0"
                                        max="100"
                                        step="0.01"
                                        placeholder="Set applicable tax"
                                        {...bind("quotation", "tax")}
                                    />
                                </div>

                                <div className="mt-5 space-y-5">
                                    <TextArea
                                        label="Payment terms"
                                        placeholder="Enter your standard payment terms"
                                        {...bind("quotation", "paymentTerms")}
                                    />
                                    <TextArea
                                        label="Warranty / support terms"
                                        {...bind("quotation", "warranty")}
                                    />
                                    <TextArea
                                        label="Default quotation notes"
                                        {...bind("quotation", "notes")}
                                    />
                                </div>

                                <div className="mt-5">
                                    <Toggle
                                        label="Show company logo"
                                        description="Include ENGEN branding in the quotation."
                                        {...toggle("quotation", "showLogo")}
                                    />
                                    <Toggle
                                        label="Show signature area"
                                        {...toggle("quotation", "showSignature")}
                                    />
                                    <Toggle
                                        label="Require admin approval"
                                        description="Prepare quotations for review before sending."
                                        {...toggle("quotation", "approvalRequired")}
                                    />
                                </div>

                                <p className="mt-5 rounded-lg bg-teal-50 p-4 text-xs leading-6 text-teal-950">
                                    Product catalogue and quotation PDF templates will connect
                                    when the Quotations module is built.
                                </p>
                            </Section>
                        )}

                        {tab === "notifications" && (
                            <Section
                                title="Notifications"
                                description="Choose which in-app reminders your workspace should use."
                            >
                                <Toggle
                                    label="Lead assignment"
                                    description="When a lead is assigned to a staff member."
                                    {...toggle("notifications", "leadAssigned")}
                                />
                                <Toggle
                                    label="Follow-up reminders"
                                    description="Before a scheduled customer follow-up."
                                    {...toggle("notifications", "followUp")}
                                />
                                <Toggle
                                    label="Overdue follow-ups"
                                    description="When a pending follow-up passes its due time."
                                    {...toggle("notifications", "overdue")}
                                />
                                <Toggle
                                    label="Quotation expiry"
                                    description="Before a quotation reaches its validity date."
                                    {...toggle("notifications", "quotationExpiry")}
                                />
                                <Toggle
                                    label="Notification sound"
                                    {...toggle("notifications", "sound")}
                                />

                                <div className="mt-6 max-w-sm">
                                    <Select
                                        label="Follow-up reminder — minutes before"
                                        options={["15", "30", "60", "120"]}
                                        {...bind("notifications", "reminderBefore")}
                                    />
                                </div>

                                <p className="mt-5 text-xs leading-6 text-slate-700">
                                    Email and WhatsApp delivery need separate integrations.
                                </p>
                            </Section>
                        )}

                        {tab === "workspace" && (
                            <Section
                                title="Workspace preferences"
                                description="Prepare display preferences for your team workspace."
                            >
                                <div className="grid gap-4 sm:grid-cols-2">
                                    <Select
                                        label="Sidebar behaviour"
                                        options={["Hover to expand", "Always expanded"]}
                                        {...bind("workspace", "sidebar")}
                                    />
                                    <Select
                                        label="Default division"
                                        options={["All divisions", ...divisions]}
                                        {...bind("workspace", "defaultDivision")}
                                    />
                                    <Select
                                        label="Table rows per page"
                                        options={["10", "25", "50"]}
                                        {...bind("workspace", "rowsPerPage")}
                                    />
                                    <Select
                                        label="Date format"
                                        options={["DD MMM YYYY", "DD/MM/YYYY", "YYYY-MM-DD"]}
                                        {...bind("workspace", "dateFormat")}
                                    />
                                </div>

                                <div className="mt-7 rounded-xl border border-slate-200 p-5">
                                    <h3 className="text-sm font-bold text-slate-950">
                                        Data & workspace controls
                                    </h3>
                                    <p className="mt-2 text-xs leading-6 text-slate-700">
                                        Excel import/export, module visibility and activity
                                        history will be connected as those modules are built.
                                    </p>
                                </div>
                            </Section>
                        )}
                    </div>

                    <footer className="flex flex-wrap items-center justify-between gap-4 border-t border-slate-200 bg-slate-50 px-5 py-4 sm:px-7">
                        <p
                            role="status"
                            className="flex items-center gap-2 text-xs font-medium text-slate-700"
                        >
                            {notice ? (
                                <>
                                    {notice === "Settings saved in this browser." && (
                                        <Check size={16} className="text-teal-800" />
                                    )}
                                    {notice}
                                </>
                            ) : (
                                "Save after making changes."
                            )}
                        </p>

                        <Button type="submit">
                            <Save size={16} />
                            Save changes
                        </Button>
                    </footer>
                </form>
            </Card>
        </div>
    );
}