import { useEffect, useState } from "react";
import { Plus, CalendarDays } from "lucide-react";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import LeadTable from "./components/LeadTable";
import AddLeadModal from "./components/AddLeadModal";
import { Button, Card } from "./components/ui";
import Dashboard from "./pages/Dashboard";
import { divisions, initialLeads } from "./data/crm";
import Settings from "./pages/Settings";
import Quotations from "./pages/Quotations";
import FollowUps from "./pages/FollowUps";
import useFollowUps from "./hooks/useFollowUps";
import PageTransition from "./components/PageTransition";
import { followUpAlert, formatFollowUpDate, isOverdue, resolveFollowUp } from "./lib/followUps";

import Customers from "./pages/Customers";
export default function App() {
  const [page, setPage] = useState("Dashboard");
  const [leads, setLeads] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("engen-crm-leads"));
      return Array.isArray(saved) ? saved : initialLeads;
    } catch {
      return initialLeads;
    }
  });
  const [leadSaveError, setLeadSaveError] = useState("");
  const [division, setDivision] = useState("All divisions");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  useEffect(() => {
    const media = window.matchMedia("(min-width: 1024px)");
    const closeDrawer = () => setSidebarOpen(false);
    media.addEventListener("change", closeDrawer);
    return () => media.removeEventListener("change", closeDrawer);
  }, []);
  const { followUps, saveFollowUps, error: followUpError, now } = useFollowUps();
  const resolvedFollowUps = followUps.map((item) => resolveFollowUp(item, leads));
  const divisionFollowUps = resolvedFollowUps.filter((item) => division === "All divisions" || item.division === division);

  const filteredLeads = leads.filter(
    (lead) => division === "All divisions" || lead.division === division
  );

  const leadAlerts = filteredLeads.filter(
    (lead) =>
      lead.priority === "High" &&
      !["Won", "Lost"].includes(lead.status)
  );
  const alerts = [
    ...divisionFollowUps.filter((item) => followUpAlert(item, now)).map((item) => ({
      id: `followup-${item.id}`, customer: item.customer, division: item.division,
      description: `${item.purpose} · ${formatFollowUpDate(item.dueAt)} IST`,
      alertLabel: isOverdue(item, now) ? "Overdue follow-up" : "Follow-up reminder",
    })),
    ...leadAlerts,
  ];

  const hasLeadContent = ["Dashboard", "Leads"].includes(page);

  function navigate(nextPage) {
    setPage(nextPage);
    setSidebarOpen(false);
    window.scrollTo({ top: 0, behavior: "instant" });
  }

  function saveLead(lead) {
    try {
      const saved = JSON.parse(localStorage.getItem("engen-crm-leads"));
      const updated = [lead, ...(Array.isArray(saved) ? saved : leads)];
      localStorage.setItem("engen-crm-leads", JSON.stringify(updated));
      setLeads(updated);
      setFormOpen(false);
      setLeadSaveError("");
    } catch {
      setLeadSaveError("Could not save the lead. Browser storage may be full or unavailable.");
    }
  }

  return (
    <div className="min-h-screen bg-[#f4f7f5] font-sans text-slate-900 antialiased selection:bg-lime-200 selection:text-teal-950 [&_button]:cursor-pointer">
      <Sidebar
        page={page}
        onNavigate={navigate}
        leadCount={leads.length}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="min-w-0 lg:ml-18">
        <Header
          key={page}
          page={page}
          alerts={alerts}
          onMenu={() => setSidebarOpen(true)}
        />

        <PageTransition key={`content-${page}`} className="mx-auto min-w-0 max-w-400 px-3 py-4 sm:px-5 sm:py-5 xl:px-6">
          <section className="mb-4 flex items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold tracking-[0.18em] text-teal-800">
                ENGEN CRM
              </p>
              <h1 className="mt-1.5 text-xl font-bold tracking-tight text-slate-950 sm:text-2xl">
                {page === "Dashboard" ? "Workspace overview" : page}
              </h1>
              <p className="mt-1.5 max-w-md text-xs leading-5 text-slate-700">
                Your customers, conversations and opportunities. Connected.
              </p>
            </div>

            {hasLeadContent && (
              <Button onClick={() => setFormOpen(true)}>
                <Plus size={17} />
                Add lead
              </Button>
            )}
          </section>

          {hasLeadContent && (
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <label className="flex items-center gap-3 text-xs font-semibold text-slate-800">
                Division
                <select
                  value={division}
                  onChange={(event) => setDivision(event.target.value)}
                  className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-900 outline-none focus:border-teal-600 focus:ring-2 focus:ring-teal-100"
                >
                  <option>All divisions</option>
                  {divisions.map((name) => (
                    <option key={name}>{name}</option>
                  ))}
                </select>
              </label>

              <span className="flex items-center gap-2 text-xs font-medium text-slate-700">
                <CalendarDays size={15} />
                {new Intl.DateTimeFormat("en-IN", {
                  dateStyle: "medium",
                  timeZone: "Asia/Kolkata",
                }).format(new Date())}
              </span>
            </div>
          )}

          {page === "Dashboard" ? (
            <Dashboard
              leads={filteredLeads}
              onViewLeads={() => navigate("Leads")}
              followUps={divisionFollowUps}
              now={now}
              onViewFollowUps={() => navigate("Follow-ups")}
            />
          ) : page === "Leads" ? (
            <LeadTable leads={filteredLeads} />
          ) : page === "Customers" ? (
            <Customers leads={leads} followUps={followUps} />
          ) : page === "Settings" ? (
            <Settings />
          ) : page === "Quotations" ? (
            <Quotations leads={leads} />
          ) : page === "Follow-ups" ? (
            <FollowUps leads={leads} followUps={followUps} onSave={saveFollowUps} now={now} storageError={followUpError} />
          ) : (
            <Card className="flex flex-col items-center gap-4 px-5 py-10 text-center">
              <span className="text-[10px] font-bold tracking-widest text-teal-800">
                NEXT MODULE
              </span>
              <h2 className="text-2xl font-bold text-slate-950">{page}</h2>
              <p className="text-sm text-slate-700">
                This screen will be built in the next step.
              </p>
              <Button
                variant="secondary"
                onClick={() => navigate("Dashboard")}
              >
                Back to dashboard
              </Button>
            </Card>
          )}

          <footer className="mt-5 flex flex-wrap justify-between gap-2 text-[11px] font-medium text-slate-600">
            <span>ENGEN · Scaling Heights</span>
            <span>{divisions.join(" / ")}</span>
          </footer>
        </PageTransition>
      </main>

      {formOpen && (
        <AddLeadModal
          saveError={leadSaveError}
          onClose={() => {
            setFormOpen(false);
            setLeadSaveError("");
          }}
          onSave={saveLead}
        />
      )}
    </div>
  );
}
